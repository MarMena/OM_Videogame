﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DragUI : MonoBehaviour {
	// Para comportamiento alternativo
	// bool usalerp
	public Image img;
	Vector2 c;
	RectTransform imgSize;
	float imgWidth, imgHeight;

	Vector2 posM, d;
	bool moving = false;

	// Use this for initialization
	void Start () { 
		
		c = img.transform.position;
		imgSize = img.GetComponent <RectTransform> ();

		imgWidth = imgSize.rect.width;
		imgHeight = imgSize.rect.height;
		
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.mousePosition.x > img.transform.position.x - imgWidth / 2 && Input.mousePosition.x < img.transform.position.x + imgWidth / 2 && Input.mousePosition.y > img.transform.position.y - imgHeight / 2 && Input.mousePosition.y < img.transform.position.y + imgHeight / 2) {
			posM = Input.mousePosition;
			d = posM - c;
			if (Input.GetMouseButtonDown (0)) {
				moving = true;
			}
			if (Input.GetMouseButtonUp (0)) {
				moving = false;
			}
		}

		if (moving) {
			//if (usalerp) {}.. lo que ya esta
			// Falta lerp o transicion
			img.transform.position = Vector2.Lerp(d + c,c,0.25f);
			c = img.transform.position;

			//else(=! usalerp).. otro comportamiento en donde la imagen se arrastra desde donde quedo el mouse y no desde el centro de la imagen
		}
		
	}
}
