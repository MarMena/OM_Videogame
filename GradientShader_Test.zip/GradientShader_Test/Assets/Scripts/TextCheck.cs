﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextCheck : MonoBehaviour {

	string inputText, defaultText;
	string[] words;
	public string[] requiredWords;
	public string[] removableWord;
	InputField inputField;
	bool word_01, word_02, word_03; 
	// Use this for initialization
	void Start () {
		inputField = gameObject.GetComponent < InputField >();
		inputText = gameObject.GetComponent < InputField >().text;
		defaultText = gameObject.GetComponent < InputField >().text;
	}
	
	// Update is called once per frame
	void Update () {
		if (inputField.isFocused) {
			inputText = gameObject.GetComponent < InputField >().text;
			words = inputText.Split (' ');
			// Separar el texto por palabras y comparar
			for (int i = 0; i < inputText.Length; i++) {
				if (words [i] == "user") {
					word_01 = true;
				}
			}
		}
		// Si el usuario borra el contenido, se reescribe el texto original
		if (inputField.text.Length < 1) {
			inputField.text = defaultText;
		}
	}
}
