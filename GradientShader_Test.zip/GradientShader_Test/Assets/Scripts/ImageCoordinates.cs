﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ImageCoordinates : MonoBehaviour {

	public Image img;
	Vector2 imgPos;
	RectTransform imgSize;
	//Vector2 mousePos;
	//Vector2 distance;
	float width;
	float height;

	//float imgPosX;
	// Use this for initialization
	void Start () {
		//img = gameObject.GetComponent <Image> ();

		imgSize = gameObject.GetComponent<RectTransform>();

		width = imgSize.rect.width;
		height = imgSize.rect.height;
		//Debug.Log (imgPos);

	}
	
	// Update is called once per frame
	void Update () {
		Vector2 mousePos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
		imgPos = gameObject.GetComponent<RectTransform>().position;
		//Debug.Log (Input.mousePosition);
		if (Input.mousePosition.x > img.transform.position.x - width/2 && Input.mousePosition.x < img.transform.position.x + width/2 && Input.mousePosition.y > img.transform.position.y - height / 2 && Input.mousePosition.y < img.transform.position.y + height / 2) {
			Debug.Log ("In");
			if (Input.GetMouseButtonDown (0)) {
				imgPos = imgPos - mousePos;
			}
		}

		else {
			Debug.Log ("Out");
		}
	}
}
